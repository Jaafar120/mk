<?php 
$tokenbot= "6223977579:AAFRN_RlcVsf3IJRZCnypaytAsPc8GKSYOk";